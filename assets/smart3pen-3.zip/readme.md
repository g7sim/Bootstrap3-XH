
Dies ist die Cmsimple-XH - Implementation  eines Bootstrap 3 - Templates mit tiefer Ebenenverschachtelung.

Sie basiert auf Smartmenus - Bootstrap (https://github.com/vadikom/smartmenus-bootstrap) und ist daher genauso unter MIT - Lizenz.

Ein ähnliches Html-Beispiel ist auf https://codepen.io/costh/pen/YXYPGx zu sehen.

Das spezielle blaue bootstrap.min.css ist auf Bootpress.org frei herunterladbar. 

Die dortigen herunterladbaren Templates laufen mit diesem Template durch einfachen Austausch der bootstrap.min.css.

Diese Version ist die erste Beta. Wünschen und Anregungen bitte unter Issues.

